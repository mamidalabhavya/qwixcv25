
import { Button } from "@/components/ui/button";

export function ThemeToggle() {
  // No-op component since we're not using theme toggle anymore
  return null;
}
